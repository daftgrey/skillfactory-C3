//Получение кукис, проверка наличия необходимого
let getCookie = function () {
    cookies = document.cookie.split(';');
    for (element in cookies) {
        element = cookies[element].split('=');
        if (element[0] === 'UserCity') {
            UserCity = decodeURIComponent(element[1])
        }
    }
};

//Записывает куки с указанным городом, а также скрывает поля ввода
let setCookie = function () {
    document.cookie = encodeURIComponent('UserCity') + '=' + encodeURIComponent(cityInput.value);
    messageField.textContent = "Ваш город: " + cityInput.value;
    inputField.setAttribute('style', 'display: none;');
};

//Удаляет куки, обновляет страницу
let deleteCookie = function () {
    document.cookie = encodeURIComponent('UserCity') + '=; max-age=-1';
    window.location.reload()
};

//Назначает кнопки, инициация проверки куки
let ready = function () {
    cityInput = document.getElementById('city-name');
    cityButton = document.getElementById('city-button');
    messageField = document.getElementById('message-field');
    inputField = document.getElementById('input-field');
    deleteButton = document.getElementById('delete-cookie');
    cityButton.addEventListener('click', setCookie);
    deleteButton.addEventListener('click', deleteCookie);
    getCookie();
    if (UserCity != null) {
        messageField.textContent = "Ваш город: " + UserCity;
        inputField.setAttribute('style', 'display: none;');
    }
};

let cityInput, cityButton, messageField, inputField, cookies, deleteButton;
let UserCity = null;


document.addEventListener('DOMContentLoaded', ready);
