//Проверяет хранилища на наличие выбранных ввариантов
let checkForChecked = function () {
  if (localStorage.checked) {
      let checked = localStorage.checked.split(',');
      for (c in checked) {
          document.getElementById(checked[c]).checked = true;
      }
      disable()
  }
};

//Сохраниет выбранные варианты в хранилище
let check = function () {
    checked = [];
    for (let i = 0; i < checkForm.elements.length; i++) {
        disable();
        if (checkForm.elements[i].checked) {
            checked.push(checkForm.elements[i].value)
        }
    }
    localStorage['checked'] = checked;
};

//Блокирует выбора, Скрывает кнопки
let disable = function() {
    for (checkbox of checkboxes)  {
           checkbox.setAttribute('disabled', 'disabled')
    }
    saveButton.setAttribute('style', 'display: none;')
};


//Назначение кнопок, инициирование проверки
let ready = function () {
    checkboxes = document.getElementsByTagName('input');
    saveButton = document.getElementById('saveButton');
    checkForm = document.getElementById('checkform')
    checkForChecked();
};

let checkboxes, saveButton;
let checked = [];
document.addEventListener('DOMContentLoaded', ready);